<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TotalEraningController extends Controller
{
    //
}
